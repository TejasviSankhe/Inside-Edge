import setuptools

setuptools.setup(name='python_hiring_test')